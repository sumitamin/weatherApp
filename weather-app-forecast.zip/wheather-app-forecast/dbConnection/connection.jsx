var mongoose = require('mongoose');

mongoose.connect('mongodb+srv://sumit:Thacarter4@cluster0-tujst.mongodb.net/test?retryWrites=true&w=majority', {useNewUrlParser: true, useUnifiedTopology: true}, (err) => {
    if (!err)
        console.log('Mongodb Connected', err);
    else
        console.log('Could not connect to Mongodb', err);
})

var schema = new mongoose.Schema({
    city : String,
    ip : String,
    wind: String,
    atmosphere: String,
    astronomy: String,
    condition: String,
    pubDate: String,
    forecast: String,
    date: Date
})

db = mongoose.model('weatherApp',schema)

module.exports = db;