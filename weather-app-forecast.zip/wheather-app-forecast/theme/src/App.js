import React, { Component,Suspense,lazy } from 'react'
import store from './store';
import { Provider } from 'react-redux';

const Weather = lazy(()=>import('./components/weather'))
export default class App extends Component {
  render() {
    return (
      <Provider  store={store}>
      <React.Fragment>
        <Suspense fallback={`Loading your App please wait`}>
          <Weather />
        </Suspense>
      </React.Fragment>
      </Provider>
    )
  }
}
